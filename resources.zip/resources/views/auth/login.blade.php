{{-- @extends('frontend.layout.layout') --}}

@extends('auth.layout.layout')

@push('styles')
    <link rel="stylesheet" href="{{ asset('css/login.css') }}">
@endpush

@section('content')

<div class="background-blobs"></div>

<main class="glass-container">
    <h1 class="logo p-4 rounded">
        <img src="{{ asset($settings['logo'] ?? '') }}" alt="Logo" class="img-fluid" style="height: 34px;" />
        <span>Pikachueshop</span>
    </h1>
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card  text-[#fff]">
                @if(request()->segment(1) == 'panel')
                    <div class="card-header">{{ __('Admin Login') }}</div>

                    <div class="card-body">
                        <form class="notify-form" method="POST" action="{{ url('panel/login') }}">
                    @else
                    <div class="card-header">{{ __('Login') }}</div>

                    <div class="card-body">
                        <form class="notify-form" method="POST" action="{{ url('login') }}">
                    @endif
                        @csrf

                        <div class="row mb-3">
                            <label for="email" class="col-md-4 col-form-label text-md-end">{{ __('Email Address') }}</label>

                            <div class="col-md-8">
                                <input id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" required autocomplete="email" autofocus>

                                @error('email')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="password" class="col-md-4 col-form-label text-md-end">{{ __('Password') }}</label>

                            <div class="col-md-8">
                                <input id="password" type="password" class="form-control @error('password') is-invalid @enderror" name="password" required autocomplete="current-password">

                                @error('password')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-md-6 offset-md-4">
                                <div class="d-flex items-center gap-2 form-check form-check" style="width: 70%; margin-left: 0;">
                                    <input class="form-check-input" type="checkbox" name="remember" id="remember" {{ old('remember') ? 'checked' : '' }}>

                                    <label class="form-check-label" for="remember">
                                        {{ __('Remember Me') }}
                                    </label>
                                </div>
                            </div>
                        </div>

                        <div class="row mb-0">
                            <div class="d-flex items-center justify-content-between col-md-8 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    {{ __('Login') }}
                                </button>

                                @if (Route::has('password.request'))
                                    <a class="btn btn-link" href="{{ route('password.request') }}">
                                        {{ __('Forgot Your Password?') }}
                                    </a>
                                @endif
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</main>
@endsection
